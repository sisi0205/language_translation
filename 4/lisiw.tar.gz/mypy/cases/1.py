x = 10
2*x + 5*x
y = 7
2*x - y
2*y - 2*x
2*x - 2 * y

x * 5*y

x/y
5*x/2*y
5*y/2*x
