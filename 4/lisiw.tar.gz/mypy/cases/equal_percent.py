x=y=z=4
print x
print y 
print z
y=3
x%(-y)
(-x)%y
x%y
(-x)%(-y)
