x=4
y=0.3
z=0.002

x+=y
print x
x-=y
print x
x*=z
print x
x//=z
print x
x/=z
print x
x%=y
print x
x**=z
print x

