def  fun_bool(a,b):
	print 1, a == 6 and b == 7
	print 2, a == 7 or b == 7
	print 5, not a == 7 and b == 7
	print 4, a == 7 and b == 7



	fun_bool(1,0);
	