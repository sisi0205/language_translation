def e(num):
    if num == 3:
       print 'boss'  
    elif num == 2:
       print 'user'
    elif num == 1:
       print 'worker'
    elif num < 0: 
       print 'error'
    else:
       print 'roadma'






def ef(num):
    if num == 3:
       print 'boss'  
    elif num == 2:
       print 'user'
    elif num == 1:
       print 'worker'
    elif num < 0: 
       print 'error'
    else:
       print 'roadman'

ef(300)

