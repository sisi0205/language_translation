def getnum(val):
	if val > 4:
		with int(raw_input("Enter a number ")) as val:
			print val


			getnum(val)
		