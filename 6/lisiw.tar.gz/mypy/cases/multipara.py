def f(x,y,z,h):
	#print 2
	print x
	print y
	print z
	print h
	return x+y



print f(2,5,7,8)




def f(x,y):
	if (x%2==1):
		return x**3+y**2
	else:
		return x**6+y**4
	#return x+y

print f(2,3)


#print 17
