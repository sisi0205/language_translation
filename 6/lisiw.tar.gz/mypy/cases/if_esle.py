def f():
  x = 0
  if x == 0: 
    print 99
    x = 0
    if x: 
      x=18
      print x
    else: 
      x=29
      print 2
    print x

f()
print 17
