def f(x=3,y=3):
	return x+y

print f()
print f(1,3)
print f(1)


def g(x,y=3):
	return x+y

print g(1)
